/***************************************************
	FileName: sshell.c
	Purpose: Execute all unix shell commands through the executable file.
	Description: Ties in all the individual pieces of the shell utility
        that we are creating.
***************************************************/
#include "parser.h"
#include "shell.h"
#include <stdio.h>
int main(void) {
  char input[MAXINPUTLINE];
  
  signal_c_init();

  printf("Welcome to the sample shell!  You may enter commands here, one\n");
  printf("per line.  When you're finished, press Ctrl+D on a line by\n");
  printf("itself.  I understand basic commands and arguments separated by\n");
  printf("spaces, redirection with < and >, up to two commands joined\n");
  printf("by a pipe, tilde expansion, and background commands with &.\n\n");
  
  printf("\n$ ");

  while (fgets(input, sizeof(input), stdin)) {
    stripcrlf(input);
    parse(input);
    printf("\n$ ");
  }
  return 0;
}
